﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Data.SqlClient;
using System.Data;
using System.Configuration;


namespace Feedback.Models
{
    public class Report
    {

        public DataTable  getReport()
        {
            DataTable posts = new DataTable();

            SqlConnection con = new SqlConnection(ConfigurationManager.ConnectionStrings["con"].ConnectionString);
            con.Open();
            SqlCommand com = new SqlCommand();
            SqlDataAdapter fetchData = new SqlDataAdapter("select posts.postid, posts.post,ul.username, FORMAT(posts.posteddatetime,('dd/MM/yyyy')) as dateandtime, (select COUNT(*) from comments where comments.postid=posts.postid) totalcomments from posts inner join userlist ul on ul.userid=posts.posterid",con);
            DataSet newDataset = new DataSet();
            fetchData.Fill(newDataset,"DataTable");
            return newDataset.Tables[0];
        }



        public DataTable getCommentByPostID(int postId)
        {
            DataTable posts = new DataTable();

            SqlConnection con = new SqlConnection(ConfigurationManager.ConnectionStrings["con"].ConnectionString);
            con.Open();
            SqlCommand com = new SqlCommand();
            SqlDataAdapter fetchData = new SqlDataAdapter("select posts.post, posts.posterid,com.comment, com.commentid, ul.username, FORMAT(com.commentdatatime,('dd/MM/yyyy')) as dateandtime "+
            @", (select  COUNT(*) from votes where votes.commentid=com.commentid and liked=1) as likes, (select  COUNT(*) from votes where votes.commentid=com.commentid and disliked=1) as dislikes "+
            @"from comments as com
            inner join userlist ul on ul.userid=com.commentatorid
            inner join posts on com.postid=posts.postid
            where posts.postid= "+postId+@"
            order by posts.posterid", con);
            DataSet newDataset = new DataSet();
            fetchData.Fill(newDataset, "DataTable");
            return newDataset.Tables[0];
        }



       
    }
}